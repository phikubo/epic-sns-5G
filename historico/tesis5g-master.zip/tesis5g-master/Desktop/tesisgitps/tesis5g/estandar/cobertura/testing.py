import matplotlib.pyplot as plt
from matplotlib.patches import RegularPolygon
import numpy as np
import math
import random
import time
import calculadora
import hacerCirculo_angulo as hc



if __name__ =="__main__":
	f=hc.dibujar_circulo(10, [0,90])
	plt.plot(4,5, 'r*')
	plt.show()
else:
	print("importado")
