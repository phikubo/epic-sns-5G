import matplotlib.pyplot as plt
import numpy as np
import math
import random
import time
import calculadora
from hexagrid import graficar
import modelos
import antenas

def capacidad():
	radio = 100/10 #en decamentros
	nivel = 1
	bs = 1
	potencia = 40
	fr=1710
	tilt = 10
	
	sector = 3
	
	x_bs = 0.0
	y_bs = 0.0

	potencia_w = potencia*10**3
	azim = calculadora.azimut_lista(0)




if __name__ =="__main__":
	print("Mod. Capacidad")
	
	#------------------------------
	#PARAMETROS
	#------------------------------
	#------------------------------
	print("Vanilla says Hello!")
	print("Un momento...")
	time.sleep(4)
	
 
	
else:
	print("Modulo MendicantVanilla:cobertura importado.")
 
 
  
