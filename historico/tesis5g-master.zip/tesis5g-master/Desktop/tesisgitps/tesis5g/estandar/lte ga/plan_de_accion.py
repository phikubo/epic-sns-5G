


#plan de solucion:

'''1. modificar el archivo sector 1, 2 y 3 para definir las coordenadas de unos usuarios
    y definirlas por defecto. Esto es con el propósito de agilizar los ensayos y obtener
    resultados esperados.
    1.1. guardar las coordenadas en un archivo de lectura con las cordenadas x,y de los ue.


'''